# Xiaomi
Repository of my smartthings device handlers for Xiaomi Devices. Created them primarily for my own use but you are free to use if you so wish.

The devices are difficult to get paired initially. Plenty of information https://community.smartthings.com/t/release-xiaomi-sensors-and-button-beta/77576

Great devices but I personally do not recommend the outlets as they appear to make my system less stable. However, other people do not seem to report this.
